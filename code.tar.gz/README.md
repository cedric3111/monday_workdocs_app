<<<<<<< HEAD
# monday_workdocs_app
=======
# Quickstart for monday workdocs

This is example code to build a simple app on top of monday workdocs. 

Check out the [full quickstart guide in the monday apps documentation](https://developer.monday.com/apps/docs/quickstart-workdocs) for a tutorial on how to set this up. 
>>>>>>> 06071f6 (Initial Commit)
